﻿using System;
using ClassLibrary;
using System.Collections.Generic;

/* TODO: переписать библиотеку классов для 2019 года.
 * Добавить класс DisciplineResults2019, в котором определить поля accumulatedGrade, student и прототипы свойств GetExaminationGrade и GetFinalGrade.
 * Унаследовать от него класс ProgrammingResults2019, переопределить в нем ToString();
 * В основной программе создать массив или список из 10 студентов, вывести сведения о них и их итоговой оценке за дисциплину.
 * Внимание: программа должна выводить сведения и оценки ВСЕХ десяти студентов, даже если при попытке вычисления итоговой оценки было вызвано исключение.
 * */

namespace TODO_Task_01
{
    class Program
    {
        static Random random = new Random();
        static void ReturnStudentInfoInCaseOfException(UnsatisfactoryException e, string message)
        {
            string studentInfo = e.Message.Remove(0, 1);
            Console.WriteLine($"{studentInfo}\n{message}");
        }
        static void Main(string[] args)
        {
            // SEStudent2018 student = new SEStudent2018("Petr", "Ivanov", 187);
            // ProgrammingResults2018 programmingResults2018 = null;

            List<SEStudent2018> students = new List<SEStudent2018>();
            for (int i = 0; i < 10; i++)
            {
                students.Add(new SEStudent2018($"Petr{i}", "Ivanov", 187));
            }
            List<ProgrammingResults2018> programmingResults2018s = new List<ProgrammingResults2018>();

            for (int i = 0; i < students.Count; i++)
            {
                try
                {
                    ProgrammingResults2018 result = new ProgrammingResults2018(26, random.Next(0, 40), random.Next(0, 10), random.Next(0, 10), students[i]);
                    programmingResults2018s.Add(result);
                    Console.WriteLine($"{result}\nИтоговая оценка: {result.GetFinalGrade}");
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '3')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 3, было очень близко :(");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '2')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 2, good luck next time (на пересдаче).");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '1')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 1, как-то совсем печально.");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '0')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 0, а Вы вообще приходили?");
                    continue;
                }
            }

            /*try
            {
                programmingResults2018 = new ProgrammingResults2018(26, 16, 3, 3, student);
            }
                catch (UnsatisfactoryException e) when (e.Message[0] == '3')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 3, было очень близко :(");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '2')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 2, good luck next time (на пересдаче).");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '1')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 1, как-то совсем печально.");
                    continue;
                }
                catch (UnsatisfactoryException e) when (e.Message[0] == '0')
                {
                    ReturnStudentInfoInCaseOfException(e, "Итоговая оценка: 0, а Вы вообще приходили?");
                    continue;
                } */
        }
    }
}
